#include "chord.h"

int main()
{
	chord C;
	C.get_command(NULL);
	//cout<<"Number of messages sent: "<<C.num_messages<<endl;
	return 0;
}